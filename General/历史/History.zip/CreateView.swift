import UIKit

// 创建View
func zViewLC(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    return myView
}
func zViewLT(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectLT(width: width, height: height, left: left, top: top)
    return myView
}
func zViewLB(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    return myView
}
func zViewCC(parent: UIView, width: CGFloat, height: CGFloat, center: UIView) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectCC(width: width, height: height, center: center)
    return myView
}
func zViewCT(parent: UIView, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    return myView
}
func zViewCB(parent: UIView, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    return myView
}
func zViewRC(parent: UIView, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    return myView
}
func zViewRT(parent: UIView, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectRT(width: width, height: height, right: right, top: top)
    return myView
}
func zViewRB(parent: UIView, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    return myView
}

// 创建Label
func zLblLC(parent: UIView, text: String, left: CGFloat, centerY: UIView) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpLC(left: left, centerY: centerY)
    return lbl
}
func zLblLT(parent: UIView, text: String, left: CGFloat, top: CGFloat) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpLT(left: left, top: top)
    return lbl
}
func zLblLB(parent: UIView, text: String, left: CGFloat, bottom: CGFloat) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpLB(left: left, bottom: bottom)
    return lbl
}
func zLblCC(parent: UIView, text: String, center: UIView) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpCC(center: center)
    return lbl
}
func zLblCT(parent: UIView, text: String, centerX: UIView, top: CGFloat) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpCT(centerX: centerX, top: top)
    return lbl
}
func zLblCB(parent: UIView, text: String, centerX: UIView, bottom: CGFloat) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpCB(centerX: centerX, bottom: bottom)
    return lbl
}
func zLblRC(parent: UIView, text: String, right: CGFloat, centerY: UIView) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpRC(right: right, centerY: centerY)
    return lbl
}
func zLblRT(parent: UIView, text: String, right: CGFloat, top: CGFloat) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpRT(right: right, top: top)
    return lbl
}
func zLblRB(parent: UIView, text: String, right: CGFloat, bottom: CGFloat) -> UILabel {
    let lbl = UILabel()
    lbl.text = text
    parent.addSubview(lbl)
    lbl.zSnpRB(right: right, bottom: bottom)
    return lbl
}

// 创建ImageView
func zImgLC(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    return img
}
func zImgLT(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectLT(width: width, height: height, left: left, top: top)
    return img
}
func zImgLB(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    return img
}
func zImgCC(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, center: UIView) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectCC(width: width, height: height, center: center)
    return img
}
func zImgCT(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    return img
}
func zImgCB(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    return img
}
func zImgRC(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    return img
}
func zImgRT(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectRT(width: width, height: height, right: right, top: top)
    return img
}
func zImgRB(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    return img
}

// 创建Icon
func zIconLC(parent: UIView, imageNamed: String, left: CGFloat, centerY: UIView) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpLC(left: left, centerY: centerY)
    return img
}
func zIconLT(parent: UIView, imageNamed: String, left: CGFloat, top: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpLT(left: left, top: top)
    return img
}
func zIconLB(parent: UIView, imageNamed: String, left: CGFloat, bottom: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpLB(left: left, bottom: bottom)
    return img
}
func zIconCC(parent: UIView, imageNamed: String, center: UIView) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpCC(center: center)
    return img
}
func zIconCT(parent: UIView, imageNamed: String, centerX: UIView, top: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpCT(centerX: centerX, top: top)
    return img
}
func zIconCB(parent: UIView, imageNamed: String, centerX: UIView, bottom: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpCB(centerX: centerX, bottom: bottom)
    return img
}
func zIconRC(parent: UIView, imageNamed: String, right: CGFloat, centerY: UIView) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRC(right: right, centerY: centerY)
    return img
}
func zIconRT(parent: UIView, imageNamed: String, right: CGFloat, top: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRT(right: right, top: top)
    return img
}
func zIconRB(parent: UIView, imageNamed: String, right: CGFloat, bottom: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpRB(right: right, bottom: bottom)
    return img
}

// 创建Button
func zBtnLC(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    return btn
}
func zBtnLT(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectLT(width: width, height: height, left: left, top: top)
    return btn
}
func zBtnLB(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    return btn
}
func zBtnCC(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, center: UIView) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectCC(width: width, height: height, center: center)
    return btn
}
func zBtnCT(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    return btn
}
func zBtnCB(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    return btn
}
func zBtnRC(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    return btn
}
func zBtnRT(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectRT(width: width, height: height, right: right, top: top)
    return btn
}
func zBtnRB(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    return btn
}

// 创建TextField
func zTxtLC(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    return txt
}
func zTxtLT(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectLT(width: width, height: height, left: left, top: top)
    return txt
}
func zTxtLB(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    return txt
}
func zTxtCC(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, center: UIView) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectCC(width: width, height: height, center: center)
    return txt
}
func zTxtCT(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    return txt
}
func zTxtCB(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    return txt
}
func zTxtRC(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    return txt
}
func zTxtRT(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectRT(width: width, height: height, right: right, top: top)
    return txt
}
func zTxtRB(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) -> UITextField {
    let txt = UITextField()
    parent.addSubview(txt)
    txt.placeholder = placeholder
    txt.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    return txt
}

// edges情况
func zViewEdges(parent: UIView, left: CGFloat, top: CGFloat, right: CGFloat, bottom: CGFloat) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpEdges(left: left, top: top, right: right, bottom: bottom)
    return myView
}
func zViewE0(parent: UIView) -> UIView  {
    let myView = UIView()
    parent.addSubview(myView)
    myView.zSnpE0()
    return myView
}
func zImgEdges(parent: UIView, imageNamed: String, left: CGFloat, top: CGFloat, right: CGFloat, bottom: CGFloat) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpEdges(left: left, top: top, right: right, bottom: bottom)
    return img
}
func zImgE0(parent: UIView, imageNamed: String) -> UIImageView {
    let img = UIImageView()
    img.image = UIImage(named: imageNamed)
    parent.addSubview(img)
    img.zSnpE0()
    return img
}
func zBtnE0(parent: UIView, type: UIButtonType) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpE0()
    return btn
}
func zBtnEdges(parent: UIView, type: UIButtonType, left: CGFloat, top: CGFloat, right: CGFloat, bottom: CGFloat) -> UIButton {
    let btn = UIButton(type: type)
    parent.addSubview(btn)
    btn.zSnpEdges(left: left, top: top, right: right, bottom: bottom)
    return btn
}



// 设置 UIView 属性
extension UIView {
    func zViewLC(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) {
        parent.addSubview(self)
        self.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    }
    func zViewLT(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectLT(width: width, height: height, left: left, top: top)
    }
    func zViewLB(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    }
    func zViewCC(parent: UIView, width: CGFloat, height: CGFloat, center: UIView) {
        parent.addSubview(self)
        self.zSnpRectCC(width: width, height: height, center: center)
    }
    func zViewCT(parent: UIView, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    }
    func zViewCB(parent: UIView, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    }
    func zViewRC(parent: UIView, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) {
        parent.addSubview(self)
        self.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    }
    func zViewRT(parent: UIView, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectRT(width: width, height: height, right: right, top: top)
    }
    func zViewRB(parent: UIView, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    }
}

// 设置 UILabel 属性
extension UILabel {
    func zLblLC(parent: UIView, text: String, left: CGFloat, centerY: UIView) {
        self.text = text
        parent.addSubview(self)
        self.zSnpLC(left: left, centerY: centerY)
    }
    func zLblLT(parent: UIView, text: String, left: CGFloat, top: CGFloat) {
        self.text = text
        parent.addSubview(self)
        self.zSnpLT(left: left, top: top)
    }
    func zLblLB(parent: UIView, text: String, left: CGFloat, bottom: CGFloat) {
        self.text = text
        parent.addSubview(self)
        self.zSnpLB(left: left, bottom: bottom)
    }
    func zLblCC(parent: UIView, text: String, center: UIView) {
        self.text = text
        parent.addSubview(self)
        self.zSnpCC(center: center)
    }
    func zLblCT(parent: UIView, text: String, centerX: UIView, top: CGFloat) {
        self.text = text
        parent.addSubview(self)
        self.zSnpCT(centerX: centerX, top: top)
    }
    func zLblCB(parent: UIView, text: String, centerX: UIView, bottom: CGFloat) {
        self.text = text
        parent.addSubview(self)
        self.zSnpCB(centerX: centerX, bottom: bottom)
    }
    func zLblRC(parent: UIView, text: String, right: CGFloat, centerY: UIView) {
        self.text = text
        parent.addSubview(self)
        self.zSnpRC(right: right, centerY: centerY)
    }
    func zLblRT(parent: UIView, text: String, right: CGFloat, top: CGFloat) {
        self.text = text
        parent.addSubview(self)
        self.zSnpRT(right: right, top: top)
    }
    func zLblRB(parent: UIView, text: String, right: CGFloat, bottom: CGFloat) {
        self.text = text
        parent.addSubview(self)
        self.zSnpRB(right: right, bottom: bottom)
    }
}

// 设置 UIImageView 属性
extension UIImageView {
    func zImgLC(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    }
    func zImgLT(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectLT(width: width, height: height, left: left, top: top)
    }
    func zImgLB(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    }
    func zImgCC(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, center: UIView) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectCC(width: width, height: height, center: center)
    }
    func zImgCT(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    }
    func zImgCB(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    }
    func zImgRC(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    }
    func zImgRT(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectRT(width: width, height: height, right: right, top: top)
    }
    func zImgRB(parent: UIView, imageNamed: String, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    }
}

// 设置 Icon 属性
extension UIImageView {
    func zIconLC(parent: UIView, imageNamed: String, left: CGFloat, centerY: UIView) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpLC(left: left, centerY: centerY)
    }
    func zIconLT(parent: UIView, imageNamed: String, left: CGFloat, top: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpLT(left: left, top: top)
    }
    func zIconLB(parent: UIView, imageNamed: String, left: CGFloat, bottom: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpLB(left: left, bottom: bottom)
    }
    func zIconCC(parent: UIView, imageNamed: String, center: UIView) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpCC(center: center)
    }
    func zIconCT(parent: UIView, imageNamed: String, centerX: UIView, top: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpCT(centerX: centerX, top: top)
    }
    func zIconCB(parent: UIView, imageNamed: String, centerX: UIView, bottom: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpCB(centerX: centerX, bottom: bottom)
    }
    func zIconRC(parent: UIView, imageNamed: String, right: CGFloat, centerY: UIView) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRC(right: right, centerY: centerY)
    }
    func zIconRT(parent: UIView, imageNamed: String, right: CGFloat, top: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRT(right: right, top: top)
    }
    func zIconRB(parent: UIView, imageNamed: String, right: CGFloat, bottom: CGFloat) {
        self.image = UIImage(named: imageNamed)
        parent.addSubview(self)
        self.zSnpRB(right: right, bottom: bottom)
    }
}

// 设置 UIButton 属性
extension UIButton {
    func zBtnLC(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) {
        parent.addSubview(self)
        self.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    }
    func zBtnLT(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectLT(width: width, height: height, left: left, top: top)
    }
    func zBtnLB(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    }
    func zBtnCC(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, center: UIView) {
        parent.addSubview(self)
        self.zSnpRectCC(width: width, height: height, center: center)
    }
    func zBtnCT(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    }
    func zBtnCB(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    }
    func zBtnRC(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) {
        parent.addSubview(self)
        self.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    }
    func zBtnRT(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectRT(width: width, height: height, right: right, top: top)
    }
    func zBtnRB(parent: UIView, type: UIButtonType, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    }
}

// 设置 UITextField 属性
extension UITextField {
    func zTxtLC(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, left: CGFloat, centerY: UIView) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectLC(width: width, height: height, left: left, centerY: centerY)
    }
    func zTxtLT(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectLT(width: width, height: height, left: left, top: top)
    }
    func zTxtLB(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, left: CGFloat, bottom: CGFloat) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectLB(width: width, height: height, left: left, bottom: bottom)
    }
    func zTxtCC(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, center: UIView) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectCC(width: width, height: height, center: center)
    }
    func zTxtCT(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, centerX: UIView, top: CGFloat) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectCT(width: width, height: height, centerX: centerX, top: top)
    }
    func zTxtCB(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, centerX: UIView, bottom: CGFloat) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectCB(width: width, height: height, centerX: centerX, bottom: bottom)
    }
    func zTxtRC(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, right: CGFloat, centerY: UIView) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectRC(width: width, height: height, right: right, centerY: centerY)
    }
    func zTxtRT(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectRT(width: width, height: height, right: right, top: top)
    }
    func zTxtRB(parent: UIView, placeholder: String, width: CGFloat, height: CGFloat, right: CGFloat, bottom: CGFloat) {
        parent.addSubview(self)
        self.placeholder = placeholder
        self.zSnpRectRB(width: width, height: height, right: right, bottom: bottom)
    }
}
