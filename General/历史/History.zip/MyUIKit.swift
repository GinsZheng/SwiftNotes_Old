//
//  myUIKit.swift
//  牛牛
//
//  Created by GinsMac on 2018/4/20.
//  Copyright © 2018年 GinsMac. All rights reserved.
//

import Foundation
import UIKit
//import Alamofire


// 所有自封装的通用的变量、函数（包括扩展）都以 z 开头

// 设备宽高、全局边距
let zScreenHeight = UIScreen.main.bounds.size.height
let zScreenWidth = UIScreen.main.bounds.size.width
let zSafeAreaHeight = zScreenHeight - 49 - 64
let zScreenEdge: CGFloat = 20
// 设置1px线段
let zSeparator = 1 / UIScreen.main.scale
// 卡片宽高
let zCardWidth = zScreenWidth - 40
let zPhotoHeight = CGFloat(Int(zCardWidth * 0.5625))





// UIScrollView Section

// 创建竖屏全屏固定高度的 UIScrollView
func zScroll(parent: UIView, top: CGFloat = 64, marginBottom: CGFloat = 0, height cellHeight: Int, cellCount: Int = 1, firstCellToTop: Int = 64) -> UIScrollView {
    // 如果元素非左上对齐布局，就一定要在元素外嵌套一个ViewLT，否则布局会出问题
    // 命名：ViewLT命名为"内容+View"，而响应区域命名为"内容+Area"
    let scrollView = UIScrollView()
    parent.addSubview(scrollView)
    scrollView.zSnpRectLT(width: zScreenWidth, height: zScreenHeight - marginBottom - top, left: 0, top: top)
    let scrollHeight = cellHeight * cellCount + firstCellToTop - Int(top)
    let heightNotEnough = cellHeight * cellCount + firstCellToTop + Int(marginBottom)
    
    let viewContainer = UIView()
    scrollView.addSubview(viewContainer)

    if heightNotEnough <= Int(zScreenHeight) {
        viewContainer.snp.makeConstraints { (x) in
            x.edges.equalTo(0)
            x.height.equalTo(scrollView).offset(1)
        }
    } else {
        viewContainer.snp.makeConstraints { (x) in
            x.edges.equalTo(0)
            x.height.equalTo(scrollHeight)
        }
    }
    return scrollView
}
// 创建竖屏全屏可变高度的 UIScrollView
func zScrollFlexibleHeight(parent: UIView, top: CGFloat = 64, marginBottom: CGFloat = 0) -> UIScrollView {
    let scrollView = UIScrollView()
    parent.addSubview(scrollView)
    scrollView.zSnpRectLT(width: zScreenWidth, height: zScreenHeight - marginBottom - top, left: 0, top: top)
    return scrollView
}

// UIScrollView扩展
extension UIScrollView {
    
    
    func zScroll(parent: UIView, top: CGFloat = 64, marginBottom: CGFloat = 0, height cellHeight: Int, cellCount: Int = 1, firstCellToTop: Int = 64) {
        parent.addSubview(self)
        self.zSnpRectLT(width: zScreenWidth, height: zScreenHeight - marginBottom - top, left: 0, top: top)
        let scrollHeight = cellHeight * cellCount + firstCellToTop - Int(top)
        let heightNotEnough = cellHeight * cellCount + firstCellToTop + Int(marginBottom)
        let viewContainer = UIView()
        self.addSubview(viewContainer)
        if heightNotEnough <= Int(zScreenHeight) {
            viewContainer.snp.makeConstraints { (x) in
                x.edges.equalTo(0)
                x.height.equalTo(self).offset(1)
            }
        } else {
            viewContainer.snp.makeConstraints { (x) in
                x.edges.equalTo(0)
                x.height.equalTo(scrollHeight)
            }
        }
    }
    
    func zScrollFlexibleHeight(parent: UIView, top: CGFloat = 64, marginBottom: CGFloat = 0) {
        parent.addSubview(self)
        self.zSnpRectLT(width: zScreenWidth, height: zScreenHeight - marginBottom - top, left: 0, top: top)
    }
    
    func zScrollSetheight(height: CGFloat) {
        let viewContainer = UIView()
        self.addSubview(viewContainer)
        if height <= zScreenHeight-64-49 { // notEnough的值即设置的值
            viewContainer.snp.makeConstraints { (x) in
                x.edges.equalTo(0)
                x.height.equalTo(self).offset(1)
            }
        } else {
            viewContainer.snp.makeConstraints { (x) in
                x.edges.equalTo(0)
                x.height.equalTo(height)
            }
        }
    }

}





// UIStackView Section

// 创建UIStackView
func zStack(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat, alignment: UIStackViewAlignment, distribution: UIStackViewDistribution, spacing: CGFloat) -> UIStackView {
    let stackView = UIStackView()
    parent.addSubview(stackView)
    stackView.zSnpRectLT(width: width, height: height, left: left, top: top)
    stackView.alignment = alignment
    stackView.distribution = distribution
    stackView.spacing = spacing
    return stackView
}
// 创建堆栈单元格
func zStackBlock(parent: UIStackView) -> UIView {
    let stackBlock = UIView()
    parent.addArrangedSubview(stackBlock)
    return stackBlock
}

// UIStackView扩展
extension UIStackView {
    
    func zStack(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat, alignment: UIStackViewAlignment, distribution: UIStackViewDistribution, spacing: CGFloat) {
        parent.addSubview(self)
        self.zSnpRectLT(width: width, height: height, left: left, top: top)
        self.alignment = alignment
        self.distribution = distribution
        self.spacing = spacing
    }
}





// UIView Section

// 创建UIView自适应高度
func zViewFlexibleHeightLT(parent: UIView, width: CGFloat, left: CGFloat, top: CGFloat) -> UIView {
    let myView = UIView()
    parent.addSubview(myView)
    myView.snp.makeConstraints { (x) in
        x.width.equalTo(width)
        x.left.equalTo(left)
        x.top.equalTo(top)
    }
    return myView
}

func zViewFlexibleHeightRT(parent: UIView, width: CGFloat, right: CGFloat, top: CGFloat) -> UIView {
    let myView = UIView()
    parent.addSubview(myView)
    myView.snp.makeConstraints { (x) in
        x.width.equalTo(width)
        x.right.equalTo(right)
        x.top.equalTo(top)
    }
    return myView
}

// UIView扩展
extension UIView {
    // 设置 UIView 属性
    func zViewFlexibleHeightLT(parent: UIView, width: CGFloat, left: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.snp.makeConstraints { (x) in
            x.width.equalTo(width)
            x.left.equalTo(left)
            x.top.equalTo(top)
        }
    }
    // 设置 UIView 属性
    func zViewFlexibleHeightRT(parent: UIView, width: CGFloat, right: CGFloat, top: CGFloat) {
        parent.addSubview(self)
        self.snp.makeConstraints { (x) in
            x.width.equalTo(width)
            x.right.equalTo(right)
            x.top.equalTo(top)
        }
    }
    // 加阴影
    func zShadow(hex: String, alpha: Float, x: CGFloat, y: CGFloat, blur: CGFloat){
        self.layer.shadowColor = UIColor.hex(hex).cgColor
        self.layer.shadowOpacity = alpha
        self.layer.shadowOffset = CGSize(width: x, height: y)
        self.layer.shadowRadius = blur
        self.layer.masksToBounds = false
    }
    // 加边框
    func zBorder(hex: String, borderWidth: CGFloat){
        self.layer.borderColor = UIColor.hex(hex).cgColor
        self.layer.borderWidth = borderWidth
    }
    // 加圆角
    func zCornerRadius(radius: CGFloat){
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
    // 遮罩
    func zMask() {
        self.layer.masksToBounds = true
    }
    // 白背景
    func bgWhite() {
        self.backgroundColor = UIColor.white
    }
    // 灰背景
    func bgGray() {
        self.backgroundColor = UIColor.hex("dddef0")
    }
    // 设置高度
    func zSetHeight(_ height: CGFloat) {
        self.snp.makeConstraints { (x) in
            x.height.equalTo(height)
        }
        self.frame.size.height = height
    }
    // 获取高度
    func zGetHeight() -> CGFloat {
        return self.frame.size.height
    }
    // 重写约束
    func zRemakeSnp(width: CGFloat, height:CGFloat, left: CGFloat, top: CGFloat) {
        self.snp.remakeConstraints { (x) in
            x.width.equalTo(width)
            x.height.equalTo(height)
            x.left.equalTo(left)
            x.top.equalTo(top)
        }
    }
    // 需要改变UIScrollView高度时，对里面的视图重写
    func zSetScrollContentHeight(height: CGFloat) {
        self.snp.makeConstraints { (x) in
            x.edges.equalTo(0)
            x.height.equalTo(height)
        }
    }
    // 重写UIScrollView高度
    func zResetScrollContentHeight(height: CGFloat) {
        self.snp.remakeConstraints { (x) in
            x.edges.equalTo(0)
            x.height.equalTo(height)
        }
    }
}





// UITextView Section

// 创建UITextView 固定高度
func zTextViewLT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) -> UITextView {
    let tv = UITextView() // 这里的fontSize要与设置字体样式时一致，确实有重叠
    tv.text = text
    tv.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
    tv.zLineSpacing(lineSpacing: lineHeight - fontSize)
    tv.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
    tv.isUserInteractionEnabled = isUserInteractionEnabled
    tv.textColor = UIColor.hex(hex)
    parent.addSubview(tv)
    tv.zSnpRectLT(width: width, height: height, left: left, top: top + tv.zSetTextViewOffSet(fontSize))
    return tv
}

func zTextViewRT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) -> UITextView {
    let tv = UITextView()
    tv.text = text
    tv.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
    tv.textColor = UIColor.hex(hex)
    tv.zLineSpacing(lineSpacing: lineHeight - fontSize)
    tv.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
    tv.isUserInteractionEnabled = isUserInteractionEnabled
    parent.addSubview(tv)
    tv.zSnpRectRT(width: width, height: height, right: right, top: top + tv.zSetTextViewOffSet(fontSize))
    return tv
}
// 创建UITextView 自适应高度
func zTextViewFlexibleHeightLT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, left: CGFloat, top: CGFloat) -> UITextView {
    let tv = UITextView() // 这里的fontSize要与设置字体样式时一致，确实有重叠
    tv.text = text // 这里有一个特别之处：如果此前设置了一个height值，后面重设这个值时，如果比之前的小，则可以，比之前的大，则无效。因此自适应高度时不能写height，或者说只能写最小的height
    tv.zLineSpacing(lineSpacing: lineHeight - fontSize)
    tv.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
    tv.isUserInteractionEnabled = isUserInteractionEnabled
    tv.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
    tv.textColor = UIColor.hex(hex)
    parent.addSubview(tv)
    tv.snp.makeConstraints{ (x) in
        x.width.equalTo(width)
        x.left.equalTo(left)
        x.top.equalTo(top + tv.zSetTextViewOffSet(fontSize))
    }
    let size = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
    let height = tv.sizeThatFits(size).height
    tv.snp.makeConstraints { (x) in
        x.height.equalTo(height)
    }
    tv.frame.size.width = width
    return tv
}

func zTextViewFlexibleHeightRT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, right: CGFloat, top: CGFloat) -> UITextView {
    let tv = UITextView()
    tv.text = text
    tv.zLineSpacing(lineSpacing: lineHeight - fontSize)
    tv.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
    tv.isUserInteractionEnabled = isUserInteractionEnabled
    tv.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
    tv.textColor = UIColor.hex(hex)
    parent.addSubview(tv)
    tv.snp.makeConstraints{ (x) in
        x.width.equalTo(width)
        x.right.equalTo(right)
        x.top.equalTo(top + tv.zSetTextViewOffSet(fontSize))
    }
    let size = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
    let height = tv.sizeThatFits(size).height
    tv.snp.makeConstraints { (x) in
        x.height.equalTo(height)
    }
    return tv
}

// UITextView扩展
extension UITextView {
    // 设置UITextView属性
    func zTextViewLT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat) {
        self.text = text
        self.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
        self.textColor = UIColor.hex(hex)
        self.zLineSpacing(lineSpacing: lineHeight - fontSize)
        self.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
        self.isUserInteractionEnabled = isUserInteractionEnabled
        parent.addSubview(self)
        self.zSnpRectLT(width: width, height: height, left: left, top: top + self.zSetTextViewOffSet(fontSize))
    }
    
    func zTextViewRT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, height: CGFloat, right: CGFloat, top: CGFloat) {
        self.text = text
        self.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
        self.textColor = UIColor.hex(hex)
        self.zLineSpacing(lineSpacing: lineHeight - fontSize)
        self.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
        self.isUserInteractionEnabled = isUserInteractionEnabled
        parent.addSubview(self)
        self.zSnpRectRT(width: width, height: height, right: right, top: top + self.zSetTextViewOffSet(fontSize))
    }
    
    func zTextViewFlexibleHeightLT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, left: CGFloat, top: CGFloat) {
        self.text = text // 这里有一个特别之处：如果此前设置了一个height值，后面重设这个值时，如果比之前的小，则可以，比之前的大，则无效。因此自适应高度时不能写height，或者说只能写最小的height
        self.zLineSpacing(lineSpacing: lineHeight - fontSize)
        self.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
        self.isUserInteractionEnabled = isUserInteractionEnabled
        self.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
        self.textColor = UIColor.hex(hex)
        parent.addSubview(self)
        self.snp.makeConstraints{ (x) in
            x.width.equalTo(width)
            x.left.equalTo(left)
            x.top.equalTo(top + self.zSetTextViewOffSet(fontSize))
        }
        let size = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let height = self.sizeThatFits(size).height
        self.snp.makeConstraints { (x) in
            x.height.equalTo(height)
        }
        self.frame.size.width = width
    }
    
    func zTextViewFlexibleHeightRT(parent: UIView, text: String, fontSize: CGFloat, hex: String, weight:UIFont.Weight, lineHeight: CGFloat, isUserInteractionEnabled: Bool, width: CGFloat, right: CGFloat, top: CGFloat) {
        self.text = text
        self.zLineSpacing(lineSpacing: lineHeight - fontSize)
        self.textContainerInset = UIEdgeInsetsMake(0, -5, 0, -5)
        self.isUserInteractionEnabled = isUserInteractionEnabled
        self.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
        self.textColor = UIColor.hex(hex)
        parent.addSubview(self)
        self.snp.makeConstraints{ (x) in
            x.width.equalTo(width)
            x.right.equalTo(right)
            x.top.equalTo(top + self.zSetTextViewOffSet(fontSize))
        }
        let size = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let height = self.sizeThatFits(size).height
        self.snp.makeConstraints { (x) in
            x.height.equalTo(height)
        }
    }
    // 不调用，定义不同字号下文本域的偏移
    func zSetTextViewOffSet(_ fontsize: CGFloat) -> CGFloat {
        switch fontsize {
        case 12, 13:
            return 2
        case 14, 15:
            return 1
        case 16:
            return 0
        case 17, 18:
            return -1
        case 20:
            return -3
        case 24:
            return -5
        default:
            return 0
        }
    }
    
    // 行距
    func zLineSpacing(lineSpacing: CGFloat) {
        let attributedString = NSMutableAttributedString(string: self.text!)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpacing //大小调整
        attributedString.addAttribute(kCTParagraphStyleAttributeName as NSAttributedStringKey, value: paragraphStyle, range: NSMakeRange(0, self.text!.count))
        self.attributedText = attributedString
        self.sizeToFit()
        // 由于目前未知的原因，设置文本颜色时，要写在这句的后面，否则文本都会变成黑色
    }
    
    func zGetTextViewHeight() -> CGFloat {
        let size = CGSize(width: self.frame.size.width, height: CGFloat.greatestFiniteMagnitude)
        let height = self.sizeThatFits(size).height
        return CGFloat(Int(height))
    }
}





// UILabel Section

// UILabel扩展
extension UILabel {
    // 不调用，全局设置文字行高
//    func labelDefaultHeight() -> Int {
//        switch self.font.pointSize {
//        case 34:
//            return 48
//        case 24:
//            return 33
//        case let x where Int(x) >= 20 && Int(x) <= 22:
//            return Int(x + 8)
//        case let x where Int(x) >= 17 && Int(x) <= 19:
//            return Int(x + 7)
//        case let x where Int(x) >= 14 && Int(x) <= 16:
//            return Int(x + 6)
//        case let x where Int(x) >= 11 && Int(x) <= 13:
//            return Int(x + 5)
//        default:
//            return 48
//        }
//    }
    func labelDefaultHeight() -> Int {
        return Int(self.font.pointSize * 1.4)
    }
    
    func setLabelHeight() { // 不调用
        self.snp.makeConstraints { (x) in
            x.height.equalTo(labelDefaultHeight())
        }
    }
    // 设置文本宽度
    func zLblSetWidth(width: CGFloat) {
        self.snp.makeConstraints { (x) in
            x.width.equalTo(width)
        }
        self.lineBreakMode = .byTruncatingTail
    }
    // 自定义样式
    func zLblFontStyle(fontSize: CGFloat, hex: String, weight:UIFont.Weight) {
        self.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
        self.textColor = UIColor.hex(hex)
        self.setLabelHeight()
    }
    // 以下为具体的自定义示例
    func zLblSpecial() {
        self.zLblFontStyle(fontSize: 22, hex: "369", weight: .thin)
    }
    // 动态计算label宽度
    func zLblGetWidth() -> CGFloat {
        let labelText = self.text! as NSString
        let size = CGSize(width: CGFloat(MAXFLOAT), height: self.frame.size.height)
        let textSize = labelText.boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: [NSAttributedStringKey.font: self.font], context: nil).size
        return CGFloat(Int(textSize.width))
    }
    // 动态计算Label高度
    func zLblGetHeight(width: CGFloat) -> CGFloat {
        _ = self.text! as NSString
        let size = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let height = self.sizeThatFits(size).height
        return CGFloat(Int(height))
    }
    // 行距
    func zLineSpacing(lineSpacing: CGFloat) {
        let attributedString = NSMutableAttributedString(string: self.text!)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = lineSpacing //大小调整
        attributedString.addAttribute(kCTParagraphStyleAttributeName as NSAttributedStringKey, value: paragraphStyle, range: NSMakeRange(0, self.text!.count))
        self.attributedText = attributedString
        self.sizeToFit()
    }
}





// UITextField Section

// UITextField扩展
extension UITextField {
    
    func zTxtStyle(fontSize: CGFloat, hex: String, weight: UIFont.Weight) {
        self.textColor = UIColor.hex(hex)
        self.font = UIFont.systemFont(ofSize: fontSize, weight: weight)
        self.clearButtonMode = .whileEditing
    }
}





// UIButton Section

// UIButton扩展
extension UIButton {
    
    func zBtnWord(setTitle: String, titleHex: String = tint, fontSize: CGFloat) { // .system
        self.setTitle(setTitle, for: .normal)
        self.setTitleColor(UIColor.hex(titleHex), for: .normal)
        self.titleLabel?.font = UIFont.systemFont(ofSize: fontSize, weight: .regular)
    }
    
    func zBtnGhost(setTitle: String, titleHex: String = tint, fontSize: CGFloat, borderHex: String = tint, borderWidth: CGFloat = 1, cornerRadius: CGFloat) { // .custom
        self.setTitle(setTitle, for: .normal)
        self.setTitleColor(UIColor.hex(titleHex), for: .normal)
        self.titleLabel?.font = UIFont.systemFont(ofSize: fontSize, weight: .regular)
        self.zBorder(hex: borderHex, borderWidth: borderWidth)
        self.zCornerRadius(radius: cornerRadius)
    }
    
    
    func zBtnSolid(setTitle: String, titleHex: String, fontSize: CGFloat, image: UIImage, highlightedImage: UIImage, disabledImage: UIImage, cornerRadius: CGFloat) { // .custom
        self.setTitle(setTitle, for: .normal)
        self.setTitleColor(UIColor.hex(titleHex), for: .normal)
        self.titleLabel?.font = UIFont.systemFont(ofSize: fontSize, weight: .regular)
        self.setBackgroundImage(image, for: .normal)
        self.setBackgroundImage(highlightedImage, for: .highlighted)
        self.setBackgroundImage(disabledImage, for: .disabled)
        self.zCornerRadius(radius: cornerRadius)
    }
    
    
    func zBtnIcon(imageNamed: String, hex: String = "333", isHightlighted: Bool = true) { // .system为线性|单色镂空icon, .custom为面性小于44*44的icon，此时hex参数没用，当然此时只有变深的效果
        self.setImage(UIImage(named: imageNamed), for: .normal)
        self.tintColor = UIColor.hex(hex)
        self.adjustsImageWhenHighlighted = isHightlighted
    }
    
    func zBtnImg(imageNamed: String, isHightlighted: Bool) { // 设置背景图时, .custom变深，.system变浅，设置前景图时则是前景图变成强调色填充，
        self.setBackgroundImage(UIImage(named: imageNamed), for: .normal)
        self.adjustsImageWhenHighlighted = isHightlighted
    }
    
    func zTarget(_ inputSelf: UIViewController, action: Selector) {
        addTarget(inputSelf, action: action, for: .touchUpInside)
    }
}




// UIViewController Section

// UIViewController扩展
extension UIViewController {
    // 一级页面跳转，调用语句写在 @objc func 中
    func push(target: UIViewController){
        self.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(target, animated: true)
        self.hidesBottomBarWhenPushed = false
    }
    // 二级以上页面跳转
    func push2(target: UIViewController){
        self.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(target, animated: true)
    }
    
    func backToRoot() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    func backToParent() {
        self.navigationController?.popViewController(animated: true)
    }
    
    func slideUp(target: UIViewController, completion: (() -> Swift.Void)? = nil) {
        self.present(target, animated: true, completion: completion)
    }
    
    func slideDown(completion: (() -> Swift.Void)? = nil) {
        self.dismiss(animated: true, completion: completion)
    }
    
    func hideNavBar() {
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.isHidden = true
    }

    func showNavBar() {
        self.navigationController?.navigationBar.isHidden = false
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.setBackgroundImage(getImageWithColor(color: "fff"), for: .default)
    }
    
    func hideTabBar() {
        self.hidesBottomBarWhenPushed = true
    }
    
}




// UITableView Section

// UITableView扩展
extension UITableView {
    
    func zTable(parent: UIView, width: CGFloat, height: CGFloat, left: CGFloat, top: CGFloat, dataSource: UITableViewDataSource, delegate: UITableViewDelegate, separatorInsetLeft: CGFloat, separatorInsetRight: CGFloat, separatorColor: String) {
        parent.addSubview(self)
        self.zSnpRectLT(width: width, height: height, left: left, top: top)
        self.dataSource = dataSource
        self.delegate = delegate
        self.separatorInset = UIEdgeInsetsMake(0, separatorInsetLeft, 0, separatorInsetRight)
        self.separatorColor = UIColor.hex(separatorColor)
    }
}




// 其他

// 把颜色转成图片
func getImageWithColor(color: String) -> UIImage {
    let rect = CGRect(x: 0, y: 0, width: 1, height: 1)
    UIGraphicsBeginImageContext(rect.size)
    let context = UIGraphicsGetCurrentContext()
    context!.setFillColor(UIColor.hex(color).cgColor)
    context!.fill(rect)
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return image!
}


// 弹窗 alert 1选项
func zAlert1(parent: AnyObject, title: String, message: String, cancelTitle: String) {
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
    let action = UIAlertAction(title: cancelTitle, style: UIAlertActionStyle.cancel, handler: nil)
    alert.addAction(action)
    parent.present(alert, animated: true, completion: nil)
}
// 弹窗 alert 2选项
func zAlert2(parent: AnyObject, title: String, message: String, cancelTitle: String, confirmTitle: String) {
    let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
    let action1 = UIAlertAction(title: confirmTitle, style: UIAlertActionStyle.default, handler: nil)
    let action2 = UIAlertAction(title: cancelTitle, style: UIAlertActionStyle.cancel, handler: nil)
    alert.addAction(action1)
    alert.addAction(action2)
    parent.present(alert, animated: true, completion: nil)
}


// 导航栏-UINavigationController
func zNavBar(parent: UIView, _ inputSelf: UIViewController, actionBack: Selector, setTitle: String) {
    let navBar = zViewLT(parent: parent, width: zScreenWidth, height: 44, left: 0, top: 20)
    let backIcon = zBtnLT(parent: navBar, type: .system, width: 58, height: 44, left: 0, top: 0)
    backIcon.zBtnIcon(imageNamed: "back", hex: "333")
    backIcon.zTarget(inputSelf, action: actionBack)
    let titleLabel = zLblCC(parent: navBar, text: setTitle, center: navBar)
    titleLabel.z18pt222Medium()
}
// 导航栏-加右上文字按钮
func zNavBarWithRightBtnWord(parent: UIView, _ inputSelf: UIViewController, actionBack: Selector, setTitle: String, rightBtn: String, actionOfRightBtn: Selector) {
    let navBar = zViewLT(parent: parent, width: zScreenWidth, height: 44, left: 0, top: 20)
    let backIcon = zBtnLT(parent: navBar, type: .system, width: 58, height: 44, left: 0, top: 0)
    backIcon.zBtnIcon(imageNamed: "back", hex: "333")
    backIcon.zTarget(inputSelf, action: actionBack)
    let titleLabel = zLblCC(parent: navBar, text: setTitle, center: navBar)
    titleLabel.z18pt222Medium()
    // 右上按钮
    let createRightBtn = UILabel()
    createRightBtn.text = rightBtn
    let btnWord = zBtnRC(parent: navBar, type: .system, width: CGFloat(createRightBtn.zLblGetWidth() + zScreenEdge * 2), height: 44, right: 0, centerY: navBar)
    btnWord.zBtnWord(setTitle: rightBtn, titleHex: tint, fontSize: 16)
    btnWord.zTarget(inputSelf, action: actionOfRightBtn)
}








